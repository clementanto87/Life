package com.example.dynamoDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DynamoDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(DynamoDbApplication.class, args);
	}

}
