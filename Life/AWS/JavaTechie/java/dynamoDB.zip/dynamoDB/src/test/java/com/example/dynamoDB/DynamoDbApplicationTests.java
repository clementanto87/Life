package com.example.dynamoDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DynamoDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
